package com.api.Secuencias;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FizzBuzzController {

    @GetMapping("/fizzbuzz/{number}")
    public String fizzBuzzSequence(@PathVariable int number) {
        StringBuilder sequence = new StringBuilder();
        for (int i = 1; i <= number; i++) {
            if (i % 3 == 0 && i % 5 == 0) {
                sequence.append("FizzBuzz ");
            } else if (i % 3 == 0) {
                sequence.append("Fizz ");
            } else if (i % 5 == 0) {
                sequence.append("Buzz ");
            } else {
                sequence.append(i).append(" ");
            }
        }
        return sequence.toString();
    }
}