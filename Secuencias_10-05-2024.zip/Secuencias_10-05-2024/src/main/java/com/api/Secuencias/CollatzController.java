/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.api.Secuencias;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CollatzController {

    @GetMapping("/collatz/{number}")
    public String collatzSequence(@PathVariable int number) {
        StringBuilder sequence = new StringBuilder();
        while (number != 1) {
            sequence.append(number).append(" ");
            if (number % 2 == 0) {
                number = number / 2;
            } else {
                number = 3 * number + 1;
            }
        }
        sequence.append(1);
        return sequence.toString();
    }
}
